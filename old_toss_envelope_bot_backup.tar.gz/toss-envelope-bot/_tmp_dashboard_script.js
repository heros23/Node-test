(()=>{
// ── 전역 상태 ──────────────────────────────────
const S = {
  theme: 'dark',
  scanMkt: 'KOSPI',
  scanFilter: 'ALL',
  chartInst: null,
  volInst: null,
  btInst: null,
  wl: { running:false, timer:null, cd:null, left:0, sessionAlerts:0, items:{}, groups:[], editingGroupId:null, groupsLoaded:false }
};

// ── 헬퍼 ───────────────────────────────────────
const $ = id => document.getElementById(id);
const fmt  = (n,d=2) => typeof n==='number' ? n.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d}) : '--';
const fmtK = (n,d=0) => typeof n==='number' ? n.toLocaleString('ko-KR',{minimumFractionDigits:d,maximumFractionDigits:d}) : '--';
const isCcy = m => m === 'US';

function fmtPrice(v, mkt){ return isCcy(mkt) ? '$'+fmt(v) : fmtK(v)+'원'; }
function fmtPctHtml(n){
  if(typeof n !== 'number') return '--';
  const c = n>0?'pos':n<0?'neg':'neu';
  return `<span class="${c}">${n>0?'+':''}${n.toFixed(2)}%</span>`;
}

const SIG_LBL = {
  STRONG_BUY:'💚 강력매수', BUY:'🟢 매수', WATCH_BUY:'👀 매수관심',
  NEUTRAL:'➖ 중립',
  WATCH_SELL:'👀 매도관심', SELL:'🔴 매도', STRONG_SELL:'🚨 강력매도',
};
const GROUP_PRESETS = {
  '256': {
    label:'256 기법',
    description:'5/20/60일 이평선이 3% 이내로 밀집하고, 종가 > 5일선 > 20일선, 거래량이 전일 대비 200% 이상 급증한 종목입니다.',
    signal_mode:'256',
    sort_by:'change_1d',
    sort_order:'desc',
  },
  BABGURU: {
    label:'밥그릇 3번 자리',
    description:'100거래일 전 대비 하락 후 112일선 또는 224일선을 골든크로스하고 5>20>60 정배열 초입입니다.',
    signal_mode:'BABGURU',
    sort_by:'from_52w_high',
    sort_order:'asc',
  },
  GONGGURI: {
    label:'공구리 기법',
    description:'최근 5봉 중 신고가, 20일선 골든크로스, 볼린저 상한선 이상, 일목균형표 선행스팬 위에 위치한 종목입니다.',
    signal_mode:'GONGGURI',
    sort_by:'pct_from_ma',
    sort_order:'desc',
  },
  ODOL: {
    label:'오돌이 기법',
    description:'장기 정배열(20>60>112) 또는 224일선 위, 5일 내 -5% 이상 낙폭 후 5일선 추세 전환, 종가 > 5일선, 거래량 150% 이상입니다.',
    signal_mode:'ODOL',
    sort_by:'change_1d',
    sort_order:'desc',
  },
};
function sigBadge(s){ return `<span class="sig sig-${s||'NA'}">${SIG_LBL[s]||s||'--'}</span>`; }
function mktBadge(m){ return `<span class="tc-mkt mkt-${m}">${m}</span>`; }
function primaryLabel(displayName, displayTicker){ return displayName || displayTicker || '--'; }
function secondaryLabel(displayName, displayTicker){
  return displayName && displayTicker && displayName !== displayTicker ? displayTicker : '';
}
function stockLabelHtml(displayName, displayTicker, cls=''){
  const secondary = secondaryLabel(displayName, displayTicker);
  return `<div class="sec-stack ${cls}"><div class="sec-name">${primaryLabel(displayName, displayTicker)}</div>${secondary?`<div class="sec-code">${secondary}</div>`:''}</div>`;
}

// ── 테마 ───────────────────────────────────────
document.getElementById.addEventListener('click', ()=>{
  S.theme = S.theme==='dark'?'light':'dark';
  document.documentElement.setAttribute('data-theme', S.theme==='light'?'light':'');
  document.getElementById.textContent = S.theme==='dark'?'☀️':'🌙';
});

// ── 탭 전환 ────────────────────────────────────
document.querySelectorAll('.nav-tab').forEach(b=>{
  b.addEventListener('click',()=>{
    document.querySelectorAll('.nav-tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    document.getElementById.classList.add('active');
    if(b.dataset.page === 'chart'){
      requestAnimationFrame(()=> loadChart());
    }
    if(b.dataset.page === 'watchlist'){
      requestAnimationFrame(()=>{
        loadExistingWatchlist();
        refreshAllWatchlistGroups();
      });
    }
  });
});

// ── 지수 현황 로드 ─────────────────────────────
async function loadIndexes(){
  const period=document.getElementById.value||20, pct=document.getElementById.value||5;
  const mkts=['KOSPI','KOSDAQ','NASDAQ'];
  await Promise.all(mkts.map(async m=>{
    try{
      const r=await fetch(`/api/index/${m}?period=${period}&pct=${pct}`);
      const d=await r.json();
      const sig=d.signal||{};
      document.getElementById;
      document.getElementById.textContent = fmtPrice(sig.close, m);
      document.getElementById.innerHTML = `${sigBadge(sig.signal)} <span style="font-size:11px;color:var(--muted);">${d.return_1y>=0?'+':''}${d.return_1y}% (1Y)</span>`;
    }catch(e){}
  }));
  document.getElementById.textContent = '업데이트: '+new Date().toLocaleTimeString();
}

// ── 스캐너 ─────────────────────────────────────
document.querySelectorAll('.mkt-tab').forEach(b=>{
  b.addEventListener('click',()=>{
    document.querySelectorAll('.mkt-tab').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    S.scanMkt=b.dataset.mkt;
    doScan();
  });
});
document.querySelectorAll('.ftab').forEach(b=>{
  b.addEventListener('click',()=>{
    document.querySelectorAll('.ftab').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    S.scanFilter=b.dataset.sf;
    doScan();
  });
});
document.getElementById.addEventListener('click', doScan);
document.getElementById.addEventListener('click', ()=>{
  if(document.getElementById.classList.contains('active')){
    loadExistingWatchlist();
    refreshAllWatchlistGroups();
    pollWl();
    return;
  }
  if(document.getElementById.classList.contains('active')) return loadChart();
  if(document.getElementById.classList.contains('active')) return runBt();
  if(document.getElementById.classList.contains('active')) return loadAccount();
  doScan();
  loadIndexes();
});

async function doScan(){
  const period=document.getElementById.value, pct=document.getElementById.value, limit=document.getElementById.value;
  document.getElementById.style.display='flex';
  document.getElementById.style.display='none';
  try{
    const r=await fetch(`/api/scan/${S.scanMkt}?period=${period}&pct=${pct}&limit=${limit}&signal=${S.scanFilter}`);
    const d=await r.json();
    renderScanTable(d.stocks||[]);
    document.getElementById.textContent=d.scanned||'--';
    const stocks=d.stocks||[];
    document.getElementById.textContent=stocks.filter(s=>s.signal==='STRONG_BUY').length;
    document.getElementById.textContent=stocks.filter(s=>['BUY','WATCH_BUY'].includes(s.signal)).length;
    document.getElementById.textContent=stocks.filter(s=>s.signal?.includes('SELL')).length;
  }catch(e){
    document.getElementById.innerHTML=`<span style="color:var(--red)">오류: ${e.message}</span>`;
  }
}

function renderScanTable(stocks){
  document.getElementById.style.display='none';
  document.getElementById.style.display='';
  const tbody=document.getElementById;
  tbody.innerHTML='';
  if(!stocks.length){
    tbody.innerHTML=`<tr><td colspan="14" style="text-align:center;padding:30px;color:var(--muted);">조건에 맞는 종목 없음</td></tr>`;
    return;
  }
  stocks.forEach(s=>{
    const tr=document.createElement('tr');
    const low=s.pct_from_lower, up=s.pct_from_upper;
    const barPct=Math.min(100,Math.max(0,(low+10)/20*100));
    const barCol=low<=0?'var(--green)':low<=5?'var(--yellow2)':'var(--muted)';
    const chg=s.change_1d;
    tr.innerHTML=`
      <td class="tc-ticker">${stockLabelHtml(s.display_name, s.display_ticker)}</td>
      <td>${mktBadge(s.market)}</td>
      <td style="font-size:11px;color:var(--muted);">${s.sector}</td>
      <td>${sigBadge(s.signal)}</td>
      <td style="font-weight:700;">${fmtPrice(s.close,s.market)}</td>
      <td>${fmtPctHtml(chg)}</td>
      <td>${fmtPrice(s.ma,s.market)}</td>
      <td style="color:var(--green);">${fmtPrice(s.lower,s.market)}</td>
      <td style="color:var(--red);">${fmtPrice(s.upper,s.market)}</td>
      <td>${fmtPctHtml(s.pct_from_ma)}</td>
      <td>${fmtPctHtml(s.pct_from_lower)}</td>
      <td>${fmtPctHtml(s.from_52w_high)}</td>
      <td><div class="pbar-wrap"><div class="pbar" style="width:${barPct}%;background:${barCol};"></div></div></td>
      <td><button onclick="event.stopPropagation();addToWl('${s.market}','${s.display_ticker}')"
          style="background:transparent;border:1px solid var(--border);border-radius:5px;padding:2px 7px;cursor:pointer;color:var(--muted);font-size:13px;">⊕</button></td>
    `;
    tr.addEventListener('click',()=>goChart(s.market, s.ticker));
    tbody.appendChild(tr);
  });
}

// ── 차트 ───────────────────────────────────────
let _tvReady=false;
let _tvPending=null;
let _tvCurrent='';

function toTvSymbol(mkt, ticker){
  const t=(ticker||'').replace(/\.(KS|KQ)$/,'').toUpperCase();
  if(mkt === 'KOSPI' || mkt === 'KOSDAQ') return 'KRX:' + t;
  return t;
}

window.addEventListener('message', function(e){
  if(!e.data || typeof e.data !== 'object') return;
  const name = e.data.name || e.data.type || '';
  if(name === 'tv-widget-ready' || name === 'tv-widget-load'){
    _tvReady = true;
    if(_tvPending){
      _tvSend(_tvPending);
      _tvPending = null;
    }
  }
});

function _tvSend(sym){
  const iframe = document.querySelector('#tv-chart-wrap iframe');
  if(!iframe || !iframe.contentWindow) return;
  iframe.contentWindow.postMessage(
    { name:'set-symbol', data:{ symbol:sym, interval:'D' } }, '*'
  );
}

function loadTvChart(mkt, ticker){
  const sym = toTvSymbol(mkt, ticker);
  if(!sym || sym === _tvCurrent) return;
  _tvCurrent = sym;
  if(_tvReady){
    _tvSend(sym);
  } else {
    _tvPending = sym;
    setTimeout(()=>{
      if(_tvPending === sym){
        _tvSend(sym);
        _tvPending = null;
      }
    }, 3000);
  }
}

async function loadChart(){
  const mkt=document.getElementById.value, ticker=document.getElementById.value.toUpperCase().trim();
  const days=document.getElementById.value, period=document.getElementById.value, pct=document.getElementById.value;
  if(!ticker) return;
  document.getElementById.style.display='flex';
  document.getElementById.style.display='none';
  document.getElementById.textContent=`📺 ${ticker} TradingView 차트`;
  try{
    const r=await fetch(`/api/chart/${mkt}/${ticker}?days=${days}&period=${period}&pct=${pct}`);
    const d=await r.json();
    if(d.error){alert('오류: '+d.error);return;}
    const sig=d.signal;
    const resolvedTicker = d.ticker || ticker;
    const displayTicker = resolvedTicker.replace(/\.(KS|KQ)$/,'');
    document.getElementById.textContent=displayTicker;
    document.getElementById.innerHTML=mktBadge(mkt);
    document.getElementById.innerHTML=sigBadge(sig.signal);
    document.getElementById.innerHTML=fmtPrice(sig.close,mkt);
    document.getElementById.innerHTML=fmtPctHtml(sig.pct_from_ma);
    document.getElementById.innerHTML=fmtPctHtml(sig.pct_from_lower);
    const pct2=(sig.upper>sig.lower)?Math.min(100,Math.max(0,(sig.close-sig.lower)/(sig.upper-sig.lower)*100)):50;
    document.getElementById.style.left=pct2.toFixed(1)+'%';
    document.getElementById.className='bviz-mark'+(pct2<=30?' zone-buy':pct2>=70?' zone-sell':'');
    document.getElementById.textContent=fmtPrice(sig.lower,mkt);
    document.getElementById.textContent=fmtPrice(sig.ma,mkt);
    document.getElementById.textContent=fmtPrice(sig.upper,mkt);
    document.getElementById.textContent=`📺 ${displayTicker} TradingView 차트`;
    document.getElementById.style.display='';
    loadTvChart(mkt, resolvedTicker);
  }catch(e){alert('오류: '+e.message);}
  document.getElementById.style.display='none';
}

document.getElementById.addEventListener('click', loadChart);
document.getElementById.addEventListener('keydown', e=>{if(e.key==='Enter')loadChart();});

function goChart(mkt, ticker){
  document.querySelectorAll('.nav-tab').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
  document.querySelector('[data-page="chart"]').classList.add('active');
  document.getElementById.classList.add('active');
  document.getElementById.value=mkt;
  document.getElementById.value=ticker.replace(/\.(KS|KQ)$/,'');
  loadChart();
}

// ── 백테스트 ───────────────────────────────────
async function runBt(){
  const mkt=document.getElementById.value, ticker=document.getElementById.value.toUpperCase().trim();
  const days=document.getElementById.value, period=document.getElementById.value, pct=document.getElementById.value;
  const sl=document.getElementById.value, tp=document.getElementById.value;
  document.getElementById.style.display='flex';
  document.getElementById.style.display='none';

  // 티커가 있으면 개별 백테스트, 없으면 시장 전체 백테스트
  const endpoint = ticker
    ? `/api/backtest/${mkt}/${encodeURIComponent(ticker)}`
    : `/api/backtest/${mkt}`;
  const displayTicker = ticker || '전체 종목';

  try{
    const r=await fetch(`${endpoint}?days=${days}&period=${period}&pct=${pct}&stop_loss=${sl}&take_profit=${tp}`);
    const d=await r.json();
    if(d.error){alert('오류: '+d.error);return;}

    if(d.mode === 'all'){
      renderAllBacktest(d, mkt, displayTicker);
    } else {
      renderSingleBacktest(d, mkt, displayTicker);
    }
    document.getElementById.style.display='';
  }catch(e){alert('오류: '+e.message);}
  document.getElementById.style.display='none';
}

function renderSingleBacktest(d, mkt, ticker){
  const cur=d.currency;
  const kpis=[
    {lb:'총 수익률',v:(d.total_return>=0?'+':'')+d.total_return+'%',c:d.total_return>=0?'var(--green)':'var(--red)',sub:'초기 자본 1천만원'},
    {lb:'총 손익',v:(d.total_pnl>=0?'+':'')+fmtK(Math.abs(d.total_pnl))+(cur==='KRW'?'원':'$'),c:d.total_pnl>=0?'var(--green)':'var(--red)',sub:'최종: '+fmtK(d.final_value)+(cur==='KRW'?'원':'$')},
    {lb:'승률',v:d.win_rate+'%',c:d.win_rate>=60?'var(--green)':d.win_rate>=40?'var(--yellow2)':'var(--red)',sub:`${d.win_count}승 / ${d.loss_count}패`},
    {lb:'거래 횟수',v:d.trade_count+'회',c:'var(--accent)',sub:'백테스트 기간'},
    {lb:'MDD',v:d.mdd+'%',c:d.mdd>-15?'var(--yellow2)':'var(--red)',sub:'최대 낙폭'},
    {lb:'평균 수익',v:'+'+d.avg_profit_pct+'%',c:'var(--green)',sub:'수익 거래 평균'},
    {lb:'평균 손실',v:d.avg_loss_pct+'%',c:'var(--red)',sub:'손실 거래 평균'},
    {lb:'손익비',v:d.avg_loss_pct?Math.abs(d.avg_profit_pct/d.avg_loss_pct).toFixed(2):'--',c:'var(--accent)',sub:'수익/손실 비율'},
  ];
  document.getElementById.innerHTML=kpis.map(k=>`<div class="kpi"><div class="kpi-label">${k.lb}</div><div class="kpi-value" style="color:${k.c};font-size:18px;">${k.v}</div><div class="kpi-sub">${k.sub}</div></div>`).join('');
  const p=d.params;
  document.getElementById.innerHTML=`<div style="display:flex;flex-direction:column;gap:6px;font-size:13px;">
    ${[['시장',mktBadge(mkt)],['티커',`<strong>${ticker}</strong>`],['MA 기간',p.period+'일'],['밴드폭','±'+p.pct+'%'],['손절',`<span style="color:var(--red)">-${p.stop_loss}%</span>`],['목표수익',`<span style="color:var(--green)">+${p.take_profit}%</span>`],['기간',p.days+'일']].map(([l,v])=>`
      <div style="display:flex;justify-content:space-between;padding:7px 10px;background:var(--panel2);border-radius:7px;">
        <span style="color:var(--muted);">${l}</span><span>${v}</span>
      </div>`).join('')}
  </div>`;
  // 거래 내역
  if(d.trades?.length){
    document.getElementById.innerHTML=`<div style="overflow-x:auto;"><table>
      <thead><tr><th>진입일</th><th>청산일</th><th>진입가</th><th>청산가</th><th>수익률</th><th>사유</th></tr></thead>
      <tbody>${d.trades.map(t=>`<tr>
        <td>${t.entry_date}</td><td>${t.exit_date}</td>
        <td>${fmtPrice(t.entry,mkt)}</td><td>${fmtPrice(t.exit,mkt)}</td>
        <td>${fmtPctHtml(t.pnl_pct)}</td>
        <td style="font-size:11px;color:var(--muted);">${t.reason}</td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } else {
    document.getElementById.innerHTML='<div style="color:var(--muted);padding:16px;">거래 내역 없음</div>';
  }
  // 차트
  if(S.btInst) S.btInst.destroy();
  let cum=0;
  const labels=['시작'], vals=[0];
  (d.trades||[]).forEach(t=>{cum+=t.pnl_pct;labels.push(t.exit_date);vals.push(parseFloat(cum.toFixed(2)));});
  S.btInst=new Chart(document.getElementById.getContext('2d'),{type:'line',data:{labels,datasets:[{
    label:'누적 수익률(%)',data:vals,borderColor:'#58a6ff',backgroundColor:'rgba(88,166,255,.08)',
    borderWidth:2,pointRadius:2,fill:true,tension:.3
  }]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:'#8b949e'}}},
    scales:{x:{ticks:{color:'#8b949e',maxTicksLimit:8,font:{size:10}},grid:{color:'rgba(255,255,255,.04)'}},
      y:{ticks:{color:'#8b949e',callback:v=>v+'%'},grid:{color:'rgba(255,255,255,.04)'}}}}});
  // 결과 영역 제목 복원
  document.getElementById.textContent = '거래 내역 (최근 20건)';
  document.getElementById.textContent = '누적 수익률 곡선';
}

function renderAllBacktest(d, mkt, ticker){
  const cur=d.currency;
  const kpis=[
    {lb:'평균 수익률',v:(d.avg_return>=0?'+':'')+d.avg_return+'%',c:d.avg_return>=0?'var(--green)':'var(--red)',sub:`${d.ticker_count}개 종목 평균`},
    {lb:'평균 승률',v:d.avg_win_rate+'%',c:d.avg_win_rate>=60?'var(--green)':d.avg_win_rate>=40?'var(--yellow2)':'var(--red)',sub:`총 ${d.total_trades}회 거래`},
    {lb:'총 수익 거래',v:d.total_wins+'회',c:'var(--green)',sub:`총 ${d.total_losses}회 손실`},
    {lb:'평균 MDD',v:d.avg_mdd+'%',c:d.avg_mdd>-15?'var(--yellow2)':'var(--red)',sub:'최대 낙폭 평균'},
    {lb:'평균 수익',v:'+'+d.avg_profit_pct+'%',c:'var(--green)',sub:'수익 거래 평균'},
    {lb:'평균 손실',v:d.avg_loss_pct+'%',c:'var(--red)',sub:'손실 거래 평균'},
    {lb:'손익비',v:d.avg_loss_pct?Math.abs(d.avg_profit_pct/d.avg_loss_pct).toFixed(2):'--',c:'var(--accent)',sub:'수익/손실 비율'},
    {lb:'대상 종목',v:d.ticker_count+'개',c:'var(--accent)',sub:mktBadge(mkt)},
  ];
  document.getElementById.innerHTML=kpis.map(k=>`<div class="kpi"><div class="kpi-label">${k.lb}</div><div class="kpi-value" style="color:${k.c};font-size:18px;">${k.v}</div><div class="kpi-sub">${k.sub}</div></div>`).join('');
  const p=d.params;
  document.getElementById.innerHTML=`<div style="display:flex;flex-direction:column;gap:6px;font-size:13px;">
    ${[['시장',mktBadge(mkt)],['대상',`<strong>${ticker}</strong>`],['MA 기간',p.period+'일'],['밴드폭','±'+p.pct+'%'],['손절',`<span style="color:var(--red)">-${p.stop_loss}%</span>`],['목표수익',`<span style="color:var(--green)">+${p.take_profit}%</span>`],['기간',p.days+'일']].map(([l,v])=>`
      <div style="display:flex;justify-content:space-between;padding:7px 10px;background:var(--panel2);border-radius:7px;">
        <span style="color:var(--muted);">${l}</span><span>${v}</span>
      </div>`).join('')}
  </div>`;

  // 상위/하위 종목 테이블
  const topRows = (d.top5||[]).map((s,i)=>`<tr><td>${i+1}</td><td>${stockLabelHtml(s.display_name, s.display_ticker, 'bt-name')}</td><td>${s.sector||'-'}</td><td>${fmtPctHtml(s.total_return)}</td><td>${s.trade_count}회</td><td>${s.win_rate}%</td></tr>`).join('');
  const botRows = (d.bottom5||[]).map((s,i)=>`<tr><td>${i+1}</td><td>${stockLabelHtml(s.display_name, s.display_ticker, 'bt-name')}</td><td>${s.sector||'-'}</td><td>${fmtPctHtml(s.total_return)}</td><td>${s.trade_count}회</td><td>${s.win_rate}%</td></tr>`).join('');
  document.getElementById.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:14px;">
      <div>
        <div style="font-size:13px;font-weight:700;color:var(--green);margin-bottom:6px;">🏆 상위 5 종목</div>
        <div style="overflow-x:auto;"><table><thead><tr><th>#</th><th>종목</th><th>섹터</th><th>수익률</th><th>거래</th><th>승률</th></tr></thead><tbody>${topRows}</tbody></table></div>
      </div>
      <div>
        <div style="font-size:13px;font-weight:700;color:var(--red);margin-bottom:6px;">⚠️ 하위 5 종목</div>
        <div style="overflow-x:auto;"><table><thead><tr><th>#</th><th>종목</th><th>섹터</th><th>수익률</th><th>거래</th><th>승률</th></tr></thead><tbody>${botRows}</tbody></table></div>
      </div>
    </div>`;

  // 전체 종목 분포 차트 (수익률 histogram)
  if(S.btInst) S.btInst.destroy();
  const returns = (d.all||[]).map(s=>s.total_return);
  const bins = [-50,-20,-10,-5,0,5,10,20,50];
  const binLabels = ['-50~-20','-20~-10','-10~-5','-5~0','0~5','5~10','10~20','20~50'];
  const counts = new Array(bins.length-1).fill(0);
  returns.forEach(v=>{
    for(let i=0;i<bins.length-1;i++){
      if(v>=bins[i] && v<bins[i+1]){counts[i]++;break;}
      if(i===bins.length-2 && v>=bins[i+1]) counts[i]++;
    }
  });
  S.btInst=new Chart(document.getElementById.getContext('2d'),{type:'bar',data:{labels:binLabels,datasets:[{
    label:'종목 수',data:counts,borderColor:'#58a6ff',backgroundColor:'rgba(88,166,255,.5)',borderWidth:1
  }]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},title:{display:true,text:'수익률 분포(%)',color:'#8b949e'}},
    scales:{x:{ticks:{color:'#8b949e',font:{size:10}},grid:{color:'rgba(255,255,255,.04)'}},
      y:{ticks:{color:'#8b949e'},grid:{color:'rgba(255,255,255,.04)'}}}}});
  // 결과 영역 제목 변경
  document.getElementById.textContent = '상위/하위 종목';
  document.getElementById.textContent = '수익률 분포';
}

document.getElementById.addEventListener('click', runBt);
document.getElementById.addEventListener('keydown', e=>{if(e.key==='Enter')runBt();});

function goBt(mkt, ticker){
  document.querySelectorAll('.nav-tab').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
  document.querySelector('[data-page="backtest"]').classList.add('active');
  document.getElementById.classList.add('active');
  document.getElementById.value=mkt;
  document.getElementById.value=ticker.replace(/\.(KS|KQ)$/,'');
  runBt();
}

// ── 워치리스트 ─────────────────────────────────
function marketLabel(mkt){
  return {US:'🇺🇸 S&P500', NASDAQ:'🇺🇸 NASDAQ100', KOSPI:'🇰🇷 코스피200', KOSDAQ:'🟠 코스닥150'}[mkt] || mkt;
}
function uid(prefix='wg'){ return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`; }
function persistGroup(group){
  const {id,name,market,preset,period,pct,limit}=group;
  return {id,name,market,preset,period,pct,limit};
}
function normalizeGroup(group){
  return {
    id: group.id || uid(),
    name: group.name || GROUP_PRESETS[group.preset]?.label || '검색 그룹',
    market: group.market || 'KOSPI',
    preset: group.preset || '256',
    period: parseInt(group.period||20),
    pct: parseFloat(group.pct||5),
    limit: parseInt(group.limit||8),
    result: group.result || null,
  };
}
function defaultWatchlistGroups(){
  return [
    {name:'코스피 256 기법', market:'KOSPI', preset:'256', period:20, pct:5, limit:8},
    {name:'코스닥 밥그릇 3번', market:'KOSDAQ', preset:'BABGURU', period:20, pct:5, limit:8},
    {name:'NASDAQ 공구리', market:'NASDAQ', preset:'GONGGURI', period:20, pct:5, limit:8},
    {name:'코스피 오돌이', market:'KOSPI', preset:'ODOL', period:20, pct:5, limit:8},
  ].map(normalizeGroup);
}
function saveWatchlistGroups(){
  localStorage.setItem('wl-groups', JSON.stringify(S.wl.groups.map(persistGroup)));
}
function ensureWatchlistGroups(){
  if(S.wl.groupsLoaded) return;
  try{
    const saved = JSON.parse(localStorage.getItem('wl-groups') || '[]');
    S.wl.groups = (saved.length ? saved : defaultWatchlistGroups()).map(normalizeGroup);
  }catch(e){
    S.wl.groups = defaultWatchlistGroups();
  }
  S.wl.groupsLoaded = true;
  saveWatchlistGroups();
  renderWatchlistGroups();
}
function setGroupStatus(msg, isError=false){
  document.getElementById.textContent = msg || '';
  document.getElementById.style.color = isError ? 'var(--red2)' : 'var(--muted)';
}
function resetGroupForm(){
  S.wl.editingGroupId = null;
  document.getElementById.value = '';
  document.getElementById.value = 'US';
  document.getElementById.value = 'BUY_SETUP';
  document.getElementById.value = 20;
  document.getElementById.value = 5;
  document.getElementById.value = 6;
  document.getElementById.textContent = '➕ 그룹 추가';
}
function getGroupRequestPayload(group){
  const preset = GROUP_PRESETS[group.preset] || GROUP_PRESETS['256'];
  return {
    id: group.id,
    name: group.name,
    market: group.market,
    period: group.period,
    pct: group.pct,
    limit: group.limit,
    signal_mode: preset.signal_mode || group.preset,
    sort_by: preset.sort_by,
    sort_order: preset.sort_order,
  };
}
function renderGroupStocks(group){
  const stocks = group.result?.stocks || [];
  if(!stocks.length) return `<div class="wg-empty">조건에 맞는 종목이 아직 없습니다.</div>`;
  return `<div class="wg-list">${stocks.map(stock=>`
    <div class="wg-row">
      <div class="wg-row-main">
        ${stockLabelHtml(stock.display_name, stock.display_ticker)}
        <div class="wg-row-sub">
          <span>${stock.sector}</span>
          <span>${fmtPrice(stock.close, stock.market)}</span>
          <span>등락 ${stock.change_1d>0?'+':''}${stock.change_1d.toFixed(2)}%</span>
          <span>52W ${stock.from_52w_high>0?'+':''}${stock.from_52w_high.toFixed(2)}%</span>
        </div>
      </div>
      <div class="wg-row-actions">
        ${sigBadge(stock.signal)}
        <button class="btn" onclick="addToWl('${stock.market}','${stock.display_ticker}', {period:${group.period}, pct:${group.pct}})">⊕ 감시</button>
        <button class="btn" onclick="goChart('${stock.market}','${stock.ticker}')">📈 차트</button>
      </div>
    </div>`).join('')}</div>`;
}
function renderWatchlistGroups(){
  ensureWatchlistGroups();
  const grid = document.getElementById;
  if(!S.wl.groups.length){
    grid.innerHTML = '<div class="wg-empty">등록된 검색 그룹이 없습니다. 위에서 새 그룹을 추가해 주세요.</div>';
    return;
  }
  grid.innerHTML = S.wl.groups.map(group=>{
    const preset = GROUP_PRESETS[group.preset] || GROUP_PRESETS.BUY_SETUP;
    const res = group.result || {};
    return `<div class="wg-card" id="wg-card-${group.id}">
      <div class="wg-top">
        <div>
          <div class="wg-name">${group.name}</div>
          <div class="wg-desc">${preset.description}</div>
          <div class="wg-meta">${marketLabel(group.market)} · MA${group.period} · ±${group.pct}% · 상위 ${group.limit}개</div>
        </div>
        <div class="wg-actions">
          <button class="btn" onclick="editWatchlistGroup('${group.id}')">수정</button>
          <button class="btn" onclick="addGroupMatchesToWatchlist('${group.id}')">일괄 감시등록</button>
          <button class="btn" onclick="refreshWatchlistGroup('${group.id}')">↻ 새로고침</button>
          <button class="btn btn-danger" onclick="deleteWatchlistGroup('${group.id}')">삭제</button>
        </div>
      </div>
      <div class="wg-kpis">
        <div class="wg-kpi"><div class="lbl">매칭</div><div class="val">${res.matched ?? '--'}</div></div>
        <div class="wg-kpi"><div class="lbl">매수</div><div class="val" style="color:var(--green2);">${res.summary?.buy ?? '--'}</div></div>
        <div class="wg-kpi"><div class="lbl">매도</div><div class="val" style="color:var(--red2);">${res.summary?.sell ?? '--'}</div></div>
        <div class="wg-kpi"><div class="lbl">스캔</div><div class="val">${res.scanned ?? '--'}</div></div>
      </div>
      <div class="wg-updated">${preset.label} · 최근 갱신 ${res.updated_at || '미실행'}</div>
      ${renderGroupStocks(group)}
    </div>`;
  }).join('');
}
function readGroupForm(){
  return normalizeGroup({
    id: S.wl.editingGroupId || uid(),
    name: document.getElementById.value.trim() || GROUP_PRESETS[document.getElementById.value]?.label || '검색 그룹',
    market: document.getElementById.value,
    preset: document.getElementById.value,
    period: parseInt(document.getElementById.value||20),
    pct: parseFloat(document.getElementById.value||5),
    limit: parseInt(document.getElementById.value||6),
  });
}
function editWatchlistGroup(groupId){
  const group = S.wl.groups.find(item=>item.id===groupId);
  if(!group) return;
  S.wl.editingGroupId = group.id;
  document.getElementById.value = group.name;
  document.getElementById.value = group.market;
  document.getElementById.value = group.preset;
  document.getElementById.value = group.period;
  document.getElementById.value = group.pct;
  document.getElementById.value = group.limit;
  document.getElementById.textContent = '💾 그룹 저장';
  setGroupStatus(`편집 중: ${group.name}`);
}
function upsertWatchlistGroup(){
  ensureWatchlistGroups();
  const group = readGroupForm();
  const idx = S.wl.groups.findIndex(item=>item.id===group.id);
  if(idx >= 0){
    S.wl.groups[idx] = {...S.wl.groups[idx], ...group, result:S.wl.groups[idx].result};
    setGroupStatus(`그룹을 수정했습니다: ${group.name}`);
  }else{
    S.wl.groups.unshift(group);
    setGroupStatus(`그룹을 추가했습니다: ${group.name}`);
  }
  saveWatchlistGroups();
  resetGroupForm();
  renderWatchlistGroups();
  refreshWatchlistGroup(group.id);
}
async function refreshWatchlistGroup(groupId){
  ensureWatchlistGroups();
  const group = S.wl.groups.find(item=>item.id===groupId);
  if(!group) return;
  const card = document.getElementById(`wg-card-${group.id}`);
  if(card) card.style.opacity = '.65';
  try{
    const payload = getGroupRequestPayload(group);
    const r = await fetch('/api/watchlist/group_scan', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload),
    });
    const d = await r.json();
    if(!r.ok || d.error) throw new Error(d.error || '그룹 조회 실패');
    group.result = d;
    renderWatchlistGroups();
    setGroupStatus(`그룹 갱신 완료: ${group.name}`);
  }catch(e){
    group.result = {stocks:[], matched:0, scanned:0, summary:{buy:0,sell:0}, updated_at:'오류'};
    renderWatchlistGroups();
    setGroupStatus(`그룹 갱신 실패: ${e.message}`, true);
  }finally{
    if(card) card.style.opacity = '';
  }
}
async function refreshAllWatchlistGroups(){
  ensureWatchlistGroups();
  if(!S.wl.groups.length){
    renderWatchlistGroups();
    return;
  }
  setGroupStatus('검색 그룹 갱신 중...');
  await Promise.all(S.wl.groups.map(group=>refreshWatchlistGroup(group.id)));
}
async function addGroupMatchesToWatchlist(groupId){
  const group = S.wl.groups.find(item=>item.id===groupId);
  if(!group) return;
  if(!group.result?.stocks?.length){
    setGroupStatus('먼저 그룹을 새로고침해 주세요.', true);
    return;
  }
  for(const stock of group.result.stocks){
    await addToWl(stock.market, stock.display_ticker, {period:group.period, pct:group.pct});
  }
  setGroupStatus(`감시 등록 완료: ${group.name}`);
}
function deleteWatchlistGroup(groupId){
  const group = S.wl.groups.find(item=>item.id===groupId);
  if(!group || !confirm(`검색 그룹을 삭제할까요?\n${group.name}`)) return;
  S.wl.groups = S.wl.groups.filter(item=>item.id!==groupId);
  saveWatchlistGroups();
  renderWatchlistGroups();
  resetGroupForm();
  setGroupStatus(`그룹 삭제: ${group.name}`);
}
function restoreDefaultWatchlistGroups(){
  S.wl.groups = defaultWatchlistGroups();
  saveWatchlistGroups();
  renderWatchlistGroups();
  resetGroupForm();
  refreshAllWatchlistGroups();
  setGroupStatus('기본 검색 그룹을 복원했습니다.');
}
async function loadExistingWatchlist(){
  try{
    const r = await fetch('/api/watchlist');
    const items = await r.json();
    S.wl.items = {};
    document.getElementById.querySelectorAll('.wl-card').forEach(card=>card.remove());
    (items||[]).forEach(item=>{
      S.wl.items[item.key] = item;
      renderWlCard(item);
    });
    document.getElementById.style.display = items?.length ? 'none' : '';
    updateWlKpi();
  }catch(e){
    console.warn('watchlist load err', e);
  }
}
document.getElementById.addEventListener('click', upsertWatchlistGroup);
document.getElementById.addEventListener('click', ()=>{ resetGroupForm(); setGroupStatus(''); });
document.getElementById.addEventListener('click', restoreDefaultWatchlistGroups);
document.getElementById.addEventListener('click', refreshAllWatchlistGroups);

function showToast(msg, type='info', ms=4500){
  const wrap=document.getElementById;
  const t=document.createElement('div');
  t.className=`toast ${type}`;
  t.innerHTML=msg;
  wrap.appendChild(t);
  setTimeout(()=>{t.style.animation='tIn .25s ease reverse';setTimeout(()=>t.remove(),260);},ms);
  if(type!=='info'&&Notification.permission==='granted')
    new Notification('엔벨로프 전략',{body:msg.replace(/<[^>]+>/g,'')});
}
if('Notification' in window && Notification.permission==='default') Notification.requestPermission();

const sfxMap2={US:'',KOSPI:'.KS',KOSDAQ:'.KQ'};

async function addToWl(mkt, ticker, options={}){
  const period=parseInt(options.period ?? document.getElementById?.value ?? 20);
  const pct=parseFloat(options.pct ?? document.getElementById?.value ?? 5);
  const key=`${mkt}:${ticker}`;
  if(S.wl.items[key]){showToast(`${ticker} 이미 감시 중`,  'info');return;}

  const errEl=document.getElementById, spinEl=document.getElementById;
  if(spinEl) spinEl.style.display='flex';
  if(errEl)  errEl.style.display='none';

  const sfx=sfxMap2[mkt]||'';
  const full=ticker.endsWith(sfx)?ticker:ticker+sfx;

  try{
    const r=await fetch('/api/watchlist/add',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({market:mkt,ticker:full,period,pct})});
    const d=await r.json();
    if(!r.ok||d.error){
      if(errEl){errEl.textContent=d.error||'추가 실패';errEl.style.display='';}
      return;
    }
    S.wl.items[key]=d.data;
    renderWlCard(d.data);
    updateWlKpi();
    document.getElementById.style.display='none';
    showToast(`<strong>${ticker}</strong> 감시 등록 완료`,'info');
  }catch(e){
    if(errEl){errEl.textContent=e.message;errEl.style.display='';}
  }finally{
    if(spinEl) spinEl.style.display='none';
  }
}

function quickAdd(mkt, ticker){
  document.getElementById.value=mkt;
  document.getElementById.value=ticker;
  addToWl(mkt, ticker);
}

document.getElementById.addEventListener('click',()=>{
  const mkt=document.getElementById.value;
  const t=document.getElementById.value.toUpperCase().trim();
  if(t) addToWl(mkt,t);
});
document.getElementById.addEventListener('keydown',e=>{
  if(e.key==='Enter'){
    const mkt=document.getElementById.value;
    const t=e.target.value.toUpperCase().trim();
    if(t) addToWl(mkt,t);
  }
});

function sigCardClass(sig){
  return {STRONG_BUY:'S_BUY',BUY:'BUY',WATCH_BUY:'W_BUY',NEUTRAL:'NEUTRAL',
    WATCH_SELL:'W_SELL',SELL:'SELL',STRONG_SELL:'S_SELL'}[sig]||'NEUTRAL';
}

function renderWlCard(item){
  const sig=item.last_signal||{};
  const grid=document.getElementById;
  let card=document.getElementById('wlc-'+item.key.replace(':','-'));
  const isNew=!card;
  if(isNew){card=document.createElement('div');card.id='wlc-'+item.key.replace(':','-');grid.appendChild(card);}

  const lower=sig.lower||0, upper=sig.upper||0, close=sig.close||0;
  const mp=(upper>lower)?Math.min(100,Math.max(0,(close-lower)/(upper-lower)*100)):50;
  const mClass=mp<=30?'zone-buy':mp>=70?'zone-sell':'';
  const sigK=sig.signal||'NEUTRAL';
  const mkt=item.market||'US';

  card.className=`wl-card ${sigCardClass(sigK)}${item.active===false?' inactive':''}`;

  const histHtml=(item.history||[]).slice().reverse().slice(0,5).map(h=>`
    <div class="wl-hist-item">
      <span class="ht">${h.time}</span>
      <span class="sig sig-${h.signal}" style="font-size:9px;padding:2px 7px;">${SIG_LBL[h.signal]||h.signal}</span>
      <span class="hv">${fmtPrice(h.close,mkt)}</span>
    </div>`).join('');

  const chg=sig.change_1d??0;
  const primaryName=primaryLabel(item.display_name, item.display_ticker);
  const secondaryTicker=secondaryLabel(item.display_name, item.display_ticker);
  card.innerHTML=`
    <div class="wl-top">
      <div>
        <div class="wl-name">
          <div class="sec-name">${primaryName}</div>
          <div class="wl-name-sub">
            ${secondaryTicker?`<span class="sec-code">${secondaryTicker}</span>`:''}
            ${item.signal_changed?'<span style="font-size:9px;background:rgba(210,153,34,.2);color:var(--yellow2);padding:1px 5px;border-radius:3px;">변화!</span>':''}
          </div>
        </div>
        <div class="wl-meta">${mktBadge(mkt)} ${item.sector} · MA${item.period} · ±${item.pct}%</div>
      </div>
      <div style="display:flex;align-items:center;gap:5px;">
        ${sigBadge(sigK)}
        <button class="wl-rm" onclick="rmWl('${item.key}')">✕</button>
      </div>
    </div>
    <div class="bviz" style="margin:6px 0 4px;">
      <div class="bviz-labels" style="font-size:9px;">
        <span>${fmtPrice(lower,mkt)}</span><span>MA ${fmtPrice(sig.ma,mkt)}</span><span>${fmtPrice(upper,mkt)}</span>
      </div>
      <div class="bviz-track"><div class="bviz-mark ${mClass}" style="left:${mp.toFixed(1)}%;"></div></div>
    </div>
    <div class="wl-nums">
      <div class="wl-num"><div class="wl-num-lbl">현재가</div><div class="wl-num-val" style="color:var(--heading);">${fmtPrice(close,mkt)}</div></div>
      <div class="wl-num"><div class="wl-num-lbl">전일대비</div><div class="wl-num-val ${chg>=0?'pos':'neg'}">${chg>=0?'+':''}${chg.toFixed(2)}%</div></div>
      <div class="wl-num"><div class="wl-num-lbl">MA 대비</div><div class="wl-num-val ${(sig.pct_from_ma||0)>=0?'pos':'neg'}">${(sig.pct_from_ma||0)>=0?'+':''}${(sig.pct_from_ma||0).toFixed(2)}%</div></div>
      <div class="wl-num"><div class="wl-num-lbl">하단대비</div><div class="wl-num-val ${(sig.pct_from_lower||0)<=0?'pos':'neu'}">${(sig.pct_from_lower||0)>=0?'+':''}${(sig.pct_from_lower||0).toFixed(2)}%</div></div>
      <div class="wl-num"><div class="wl-num-lbl">상단대비</div><div class="wl-num-val ${(sig.pct_from_upper||0)>=0?'neg':'neu'}">${(sig.pct_from_upper||0)>=0?'+':''}${(sig.pct_from_upper||0).toFixed(2)}%</div></div>
      <div class="wl-num"><div class="wl-num-lbl">알림</div><div class="wl-num-val" style="color:var(--yellow2);">${item.alert_count||0}회</div></div>
    </div>
    ${item.active===false?'<div style="font-size:10px;color:var(--muted);padding:3px 0;">⚠️ NEUTRAL – 매매 대상 이탈</div>':''}
    <div class="wl-hist">
      <div class="wl-hist-title">신호 변화 이력</div>
      <div class="wl-hist-list">${histHtml||'<span style="font-size:10px;color:var(--muted);">변화 없음</span>'}</div>
    </div>
    <div style="font-size:9px;color:var(--muted);text-align:right;margin-top:5px;">갱신 ${sig.updated_at||'--'} · 등록 ${item.added_at||'--'}</div>
    <div class="wl-footer">
      <button class="btn" onclick="goChart('${mkt}','${item.ticker}')">📈 차트</button>
      <button class="btn" onclick="goBt('${mkt}','${item.display_ticker}')">⚡ 백테스트</button>
    </div>`;

  if(!isNew&&item.signal_changed){card.classList.add('flash');setTimeout(()=>card.classList.remove('flash'),700);}
}

async function rmWl(key){
  await fetch('/api/watchlist/remove/'+key,{method:'DELETE'});
  delete S.wl.items[key];
  document.getElementById('wlc-'+key.replace(':','-'))?.remove();
  updateWlKpi();
  if(!Object.keys(S.wl.items).length) document.getElementById.style.display='';
}

function updateWlKpi(){
  const items=Object.values(S.wl.items);
  document.getElementById.textContent=items.length;
  document.getElementById.textContent=items.filter(i=>(i.last_signal?.signal||'').includes('BUY')).length;
  document.getElementById.textContent=items.filter(i=>(i.last_signal?.signal||'').includes('SELL')).length;
  document.getElementById.textContent=S.wl.sessionAlerts;
}

async function pollWl(){
  if(!Object.keys(S.wl.items).length) return;
  try{
    const r=await fetch('/api/watchlist/update',{method:'POST'});
    const d=await r.json();
    (d.items||[]).forEach(item=>{
      const prev=S.wl.items[item.key];
      const ps=prev?.last_signal?.signal, ns=item.last_signal?.signal;
      S.wl.items[item.key]=item;
      if(ps&&ns&&ps!==ns){
        S.wl.sessionAlerts++;
        const isBuy=ns.includes('BUY'), isSell=ns.includes('SELL');
        showToast(`<strong>${item.display_ticker}</strong> ${SIG_LBL[ps]||ps} → ${SIG_LBL[ns]||ns} · ${fmtPrice(item.last_signal?.close,item.market)}`,isBuy?'buy':isSell?'sell':'info');
      }
      renderWlCard(item);
    });
    updateWlKpi();
  }catch(e){console.warn('poll err',e);}
}

function startWl(){
  S.wl.running=true;
  document.getElementById.className='wl-dot on';
  document.getElementById.textContent='실시간 감시 중';
  document.getElementById.textContent='⏹ 정지';
  const interval=parseInt(document.getElementById.value);
  S.wl.left=interval;
  if(S.wl.cd) clearInterval(S.wl.cd);
  S.wl.cd=setInterval(()=>{
    S.wl.left--;
    document.getElementById.textContent=`(${S.wl.left}초 후 갱신)`;
    if(S.wl.left<=0){S.wl.left=parseInt(document.getElementById.value);pollWl();}
  },1000);
  pollWl();
}
function stopWl(){
  S.wl.running=false;
  if(S.wl.cd) clearInterval(S.wl.cd);
  document.getElementById.className='wl-dot pause';
  document.getElementById.textContent='일시 정지';
  document.getElementById.textContent='▶ 시작';
  document.getElementById.textContent='';
}
document.getElementById.addEventListener('click',()=>S.wl.running?stopWl():startWl());
document.getElementById.addEventListener('change',()=>{if(S.wl.running){stopWl();startWl();}});
document.getElementById.addEventListener('click',async()=>{
  if(!confirm('전체 삭제?')) return;
  for(const k of Object.keys(S.wl.items)) await fetch('/api/watchlist/remove/'+k,{method:'DELETE'});
  S.wl.items={};
  document.getElementById.querySelectorAll('.wl-card').forEach(c=>c.remove());
  document.getElementById.style.display='';
  updateWlKpi();
});

// ── 초기화 ─────────────────────────────────────
resetGroupForm();
ensureWatchlistGroups();
loadExistingWatchlist();
refreshAllWatchlistGroups();

// ══════════════════════════════════════════════
//  계좌 & 운영현황 탭
// ══════════════════════════════════════════════

// 숫자 포맷 (한국 원화용)
function fmtWon(v){ return typeof v==='number'? v.toLocaleString('ko-KR')+'원' : '--'; }
function fmtAccountMoney(v, currency='KRW'){
  if(typeof v!=='number') return '--';
  return currency === 'USD'
    ? '$' + v.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})
    : v.toLocaleString('ko-KR') + '원';
}
function fmtRate(v){ if(typeof v!=='number') return '--'; return (v*100).toFixed(2)+'%'; }

function getStockName(item){
  const code = String(item?.symbol||item?.stock_code||item?.code||'N/A');
  const nameMap={'005930':'삼성전자','000660':'SK하이닉스','226950':'올릭스'};
  return item?.name||item?.stock_name||nameMap[code.replace(/^A/,'')]||'종목명 없음';
}

function renderOrderKV(obj, emptyMsg){
  if(!obj||!Object.keys(obj).length) return `<div class="empty-row">${emptyMsg}</div>`;
  return Object.entries(obj).map(([k,v])=>`
    <div class="order-kv">
      <div class="ok">${k}</div>
      <div class="ov">${typeof v==='object'&&v!==null?JSON.stringify(v,null,2):String(v)}</div>
    </div>`).join('');
}

function renderOrderHistory(list){
  if(!list||!list.length) return '<tr><td colspan="5" class="empty-row">주문 이력이 없습니다.</td></tr>';
  return list.slice(-5).reverse().map(item=>{
    const side = String(item.side||'').toLowerCase();
    const sc = side==='sell'?'color:var(--accent)':'color:var(--red)';
    const code = item.symbol||item.stock_code||item.code||'N/A';
    const name = getStockName(item);
    const ts = item.timestamp ? new Date(item.timestamp).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'}) : item.timestamp||'';
    const statusColor = item.accepted?'color:var(--green)':'color:var(--red)';
    return `<tr>
      <td style="color:var(--muted)">${ts}</td>
      <td>${name} <span style="color:var(--accent);font-size:11px;">(${code})</span></td>
      <td><span style="${sc};font-weight:700;">${String(item.side||'').toUpperCase()}</span></td>
      <td>${item.quantity||0}</td>
      <td><span style="${statusColor};font-weight:600;">${item.accepted?'성공':'거절'}</span></td>
    </tr>`;
  }).join('');
}

function renderPositions(list){
  if(!list||!list.length) return '<tr><td colspan="4" class="empty-row">보유 포지션이 없습니다.</td></tr>';
  return list.map(p=>{
    const code = p.symbol||p.stock_code||p.code||'N/A';
    const name = getStockName(p);
    const side = String(p.side||(Number(p.quantity||0) < 0 ? 'SELL' : 'HOLD')).toUpperCase();
    const sc = side==='SELL' ? 'color:var(--red2)' : side==='BUY' ? 'color:var(--green2)' : 'color:var(--accent)';
    const ccy = p.currency === 'USD' ? 'USD' : 'KRW';
    return `<tr>
      <td>${name} <span style="color:var(--accent);font-size:11px;">(${code})</span></td>
      <td><span style="${sc};font-weight:700;">${side}</span></td>
      <td>${p.quantity||0}</td>
      <td>${fmtAccountMoney((p.value||p.market_value||0), ccy)}</td>
    </tr>`;
  }).join('');
}

function renderHoldings(list, mockMode, emptyMsg){
  if(!list||!list.length) return `<div class="empty-row">${emptyMsg}</div>`;
  return list.map(item=>{
    const code = item.symbol||item.stock_code||item.code||'N/A';
    const name = getStockName(item);
    const qty  = Number(item.quantity||0);
    const avg  = Number(item.average_price??item.avg_price??item.averagePurchasePrice??0);
    const cur  = Number(item.current_price??item.last_price??item.lastPrice??item.price??(item.market_value?item.market_value/Math.max(qty,1):avg));
    const mv   = Number(item.market_value??item.value??qty*cur);
    const pnl  = Number(item.pnl??item.unrealized_pnl??(mv - qty*avg));
    const ccy  = item.currency === 'USD' ? 'USD' : 'KRW';
    const pc   = pnl>=0?'color:var(--green2)':'color:var(--red2)';
    const entryLabel = mockMode?'모의매수':(item.side||'실계좌 보유');
    const qtyText = Number.isInteger(qty) ? qty.toLocaleString('ko-KR') : qty.toLocaleString('en-US', {maximumFractionDigits:5});
    return `<div class="holding-row">
      <div>
        <div class="hn">${name}</div>
        <div class="hc">${code}</div>
        <div class="hm">수량 ${qtyText}개 · 평균가 ${fmtAccountMoney(avg, ccy)} · 현재가 ${fmtAccountMoney(cur, ccy)}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:13px;font-weight:700;color:var(--heading);">${fmtAccountMoney(mv, ccy)}</div>
        <div style="font-size:12px;${pc};font-weight:600;">평가손익 ${pnl>=0?'+':'-'}${fmtAccountMoney(Math.abs(pnl), ccy)}</div>
        <div class="hm">${entryLabel}</div>
      </div>
    </div>`;
  }).join('');
}

function hasLiveAccountData(liveAc){
  return Boolean(liveAc && liveAc.mode==='live' && !liveAc.error && liveAc.account_id && liveAc.account_id!=='demo-account');
}

function renderAccountBars(list){
  if(!list||!list.length) return '<div class="empty-row">연동된 실계좌 포지션이 없습니다.</div>';
  const items = list.map(item=>{
    const qty = Number(item.quantity||0);
    const avg = Number(item.average_price??item.avg_price??item.averagePurchasePrice??0);
    const mv  = Number(item.market_value??item.value??0);
    const pnl = Number(item.pnl??item.unrealized_pnl??(mv - qty*avg));
    return {
      label: String(item.symbol||item.code||getStockName(item)||'N/A').slice(0, 10),
      name: getStockName(item),
      market_value: mv,
      pnl,
      currency: item.currency === 'USD' ? 'USD' : 'KRW',
    };
  }).filter(item=>item.market_value > 0).sort((a,b)=>b.market_value-a.market_value).slice(0,7);
  if(!items.length) return '<div class="empty-row">차트로 표시할 보유 종목이 없습니다.</div>';
  const maxVal = Math.max(...items.map(item=>item.market_value), 1);
  return items.map(item=>{
    const height = Math.max(18, Math.round(item.market_value / maxVal * 100));
    const pnlColor = item.pnl >= 0 ? 'var(--green2)' : 'var(--red2)';
    const barColor = item.pnl >= 0 ? 'linear-gradient(180deg, rgba(86,211,100,.95), rgba(63,185,80,.55))' : 'linear-gradient(180deg, rgba(255,123,114,.95), rgba(248,81,73,.55))';
    return `<div style="flex:1;min-width:72px;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;gap:8px;">
      <div style="font-size:11px;color:var(--muted);text-align:center;line-height:1.35;">
        ${fmtAccountMoney(item.market_value, item.currency)}<br/>
        <span style="${pnlColor};font-weight:700;">${item.pnl>=0?'+':'-'}${fmtAccountMoney(Math.abs(item.pnl), item.currency)}</span>
      </div>
      <div class="cbar" title="${item.name} · ${fmtAccountMoney(item.market_value, item.currency)}" style="height:${height}%;width:100%;max-width:56px;background:${barColor};"></div>
      <div style="font-size:11px;font-weight:700;color:var(--heading);text-align:center;line-height:1.2;word-break:break-word;">${item.label}</div>
    </div>`;
  }).join('');
}

let acMockMode = false;

async function loadAccount(){
  document.getElementById.textContent = '불러오는 중...';
  try {
    const res = await fetch('/api/account', {cache:'no-store'});
    const {dashboard:dd, runtime:rt, config:cfg, live_account:liveAc} = await res.json();

    // 모의투자 모드: 실계좌가 살아 있으면 기본적으로 실계좌를 우선 노출
    const storedMockPref = localStorage.getItem('ac-mock-mode');
    const liveConnected = hasLiveAccountData(liveAc);
    acMockMode = storedMockPref === null
      ? Boolean(cfg?.mock_mode && !liveConnected)
      : storedMockPref === 'true';
    const modeBadge = document.getElementById;
    modeBadge.textContent = acMockMode ? '모의투자 모드' : (liveConnected ? '실전 계좌' : '실계좌 연결 대기');
    modeBadge.classList.toggle('mock', acMockMode);
    document.getElementById.textContent = acMockMode ? '모의투자 ON' : '모의투자 OFF';

    const liveCurrency = liveAc?.positions?.some(p=>p.currency==='USD') ? 'USD' : 'KRW';

    // 계좌 데이터 선택: 실전 모드에서는 live_account를 최우선으로 사용
    const acSrc = acMockMode
      ? (rt?.mock_account || rt?.account || dd?.account)
      : (liveAc || rt?.account || dd?.account);
    const ac = {
      cash:        acSrc?.cash        ?? dd?.account?.cash        ?? 0,
      assets:      acSrc?.assets      ?? dd?.account?.assets      ?? 0,
      daily_pnl:   acSrc?.daily_pnl   ?? dd?.account?.daily_pnl   ?? 0,
      return_rate: acSrc?.return_rate ?? dd?.account?.return_rate ?? 0,
      error:       acSrc?.error,
      account_id:  acSrc?.account_id  || 'demo-account',
      account_seq: acSrc?.account_seq,
      account_type: acSrc?.account_type,
      mode:        acSrc?.mode        || 'demo',
      currency:    acMockMode ? 'KRW' : liveCurrency,
    };
    const suf = ac.error && !liveConnected ? ' (데모값)' : '';

    document.getElementById.textContent   = fmtAccountMoney(ac.cash, ac.currency) + suf;
    document.getElementById.textContent = fmtAccountMoney(ac.assets, ac.currency) + suf;
    document.getElementById.textContent    = fmtAccountMoney(ac.daily_pnl, ac.currency) + suf;
    document.getElementById.textContent   = fmtRate(ac.return_rate) + suf;

    // 색 적용
    const pnlColor = ac.daily_pnl >= 0 ? 'var(--green2)' : 'var(--red2)';
    const rateColor = ac.return_rate >= 0 ? 'var(--green2)' : 'var(--red2)';
    document.getElementById.style.color  = pnlColor;
    document.getElementById.style.color = rateColor;

    const failMsg = ac.error ? ` | 오류: ${ac.error}` : '';
    const liveMeta = [ac.account_seq != null ? `seq ${ac.account_seq}` : '', ac.account_type || '', ac.currency].filter(Boolean).join(' / ');
    const connectionLabel = acMockMode
      ? (liveConnected ? '실계좌 연결됨 · 모의 보기 중' : '모의 계좌 표시 중')
      : (liveConnected ? '실계좌 연동됨' : '실계좌 연결 대기');
    document.getElementById.textContent = `${connectionLabel} | 계좌: ${ac.account_id}${liveMeta ? ` (${liveMeta})` : ''} / 모드: ${ac.mode}${failMsg}`;
    if(ac.error && !liveConnected) document.getElementById.textContent += ' | 실제 계좌 연동은 토스증권 API 권한이 필요합니다.';

    // 보유 종목
    const holdings = acMockMode
      ? (rt?.mock_holdings || rt?.holdings || rt?.positions || [])
      : (liveAc?.positions || rt?.holdings || rt?.positions || []);
    const visH = acMockMode ? holdings.filter(i=>i.kind==='mock'||i.side==='모의매수'||i.mode==='mock') : holdings;
    const emptyMsg = acMockMode ? '모의투자 모드에서는 모의매수한 종목만 표시됩니다.' : (liveConnected ? '연동된 보유 종목이 없습니다.' : '실계좌를 아직 불러오지 못했습니다.');
    document.getElementById.innerHTML = renderHoldings(visH, acMockMode, emptyMsg);

    // 연동 계좌 보유 비중 차트
    document.getElementById.innerHTML = renderAccountBars(visH);

    // 운영 상태
    const livePositionCount = liveAc?.positions?.length ?? (rt?.positions||[]).length;
    document.getElementById.innerHTML = [
      ['상태',   rt?.status||'not-ready'],
      ['전략',   rt?.strategy||'n/a'],
      ['API 모드', ac.mode || rt?.api_mode || 'demo'],
      ['계좌',   ac.account_id || rt?.account?.account_id || 'demo'],
      ['포지션', livePositionCount + '건'],
    ].map(([l,v])=>`<div class="kpi"><div class="kpi-label">${l}</div><div class="kpi-value" style="font-size:15px;">${v}</div></div>`).join('');

    // 백테스트 결과
    const bt = dd?.backtest||{};
    document.getElementById.innerHTML = [
      ['총 수익률',   ((bt.total_return||0)*100).toFixed(1)+'%'],
      ['연환산 수익률',((bt.annualized_return||0)*100).toFixed(1)+'%'],
      ['샤프 지수',  (bt.sharpe||0).toFixed(2)],
      ['최대 낙폭',  ((bt.max_drawdown||0)*100).toFixed(1)+'%'],
    ].map(([l,v])=>`<div class="kpi"><div class="kpi-label">${l}</div><div class="kpi-value" style="font-size:15px;">${v}</div></div>`).join('');

    // LLM
    const llm = dd?.llm||{};
    document.getElementById.innerHTML = `<div class="kpi-label">모드</div><div class="kpi-value" style="font-size:14px;">${llm.mode||'fallback'}</div>`;
    document.getElementById.innerHTML = (llm.recommendations||[]).map(r=>`<li>${r}</li>`).join('');

    // 학습 리포트
    const lr = dd?.learning_report||{};
    document.getElementById.textContent  = lr.summary||'리포트가 아직 준비되지 않았습니다.';
    document.getElementById.innerHTML    = (lr.lessons||[]).map(i=>`<li>${i}</li>`).join('');
    document.getElementById.innerHTML    = (lr.improvements||[]).map(i=>`<li>${i}</li>`).join('');
    document.getElementById.innerHTML       = (lr.next_actions||[]).map(i=>`<li>${i}</li>`).join('');

    // 주문 미리보기 / 결과
    document.getElementById.innerHTML = renderOrderKV(rt?.order_preview||{}, '주문 미리보기가 없습니다.');
    document.getElementById.innerHTML  = renderOrderKV(rt?.order_result||{},  '주문 결과가 없습니다.');

    // 주문 이력
    document.getElementById.innerHTML   = renderOrderHistory(rt?.order_history||[]);
    // 포지션
    document.getElementById.innerHTML     = renderPositions(acMockMode ? (rt?.positions||[]) : (liveAc?.positions || rt?.positions || []));

    // API 설정 폼
    document.getElementById.value   = cfg?.base_url   || dd?.config?.base_url   || '';
    document.getElementById.value    = cfg?.api_key    || dd?.config?.api_key    || '';
    document.getElementById.value = cfg?.api_secret || dd?.config?.api_secret || '';

    document.getElementById.textContent = '최종 갱신: ' + new Date().toLocaleTimeString('ko-KR');
  } catch(e){
    document.getElementById.textContent = '데이터 로드 실패: ' + e.message;
    document.getElementById.textContent = '';
  }
}

// 탭 진입 시 자동 로드
document.querySelector('[data-page="account"]').addEventListener('click', loadAccount);

// 새로고침
document.getElementById.addEventListener('click', loadAccount);

// 토스증권 로그인
document.getElementById.addEventListener('click', ()=>{
  window.open('https://www.tossinvest.com/signin?redirectUrl=%2Faccount','_blank','noopener,noreferrer');
});

// 모의투자 토글
document.getElementById.addEventListener('click', async()=>{
  acMockMode = !acMockMode;
  localStorage.setItem('ac-mock-mode', String(acMockMode));
  await fetch('/api/save_config',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({mock_mode: acMockMode})});
  loadAccount();
});

// API 설정 저장
document.getElementById.addEventListener('click', async()=>{
  const payload = {
    base_url:   document.getElementById.value.trim(),
    api_key:    document.getElementById.value.trim(),
    api_secret: document.getElementById.value.trim(),
    mock_mode: false,
  };
  if(!payload.api_key||!payload.api_secret){
    document.getElementById.textContent = '⚠️ API Key와 API Secret를 모두 입력해 주세요.'; return;
  }
  try {
    const r = await fetch('/api/save_config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const j = await r.json();
    localStorage.setItem('ac-mock-mode', 'false');
    acMockMode = false;
    document.getElementById.textContent = (j.message||'저장됨') + ' ✓';
    loadAccount();
  } catch(e){ document.getElementById.textContent = '저장 실패: '+e.message; }
});

// API 설정 초기화
document.getElementById.addEventListener('click', async()=>{
  document.getElementById.value = document.getElementById.value = document.getElementById.value = '';
  try {
    const r = await fetch('/api/save_config',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({base_url:'',api_key:'',api_secret:'',mock_mode:true})});
    const j = await r.json();
    localStorage.setItem('ac-mock-mode', 'true');
    acMockMode = true;
    document.getElementById.textContent = j.message||'초기화됨';
  } catch(e){ document.getElementById.textContent = '초기화 실패: '+e.message; }
});

// 5초마다 자동 갱신 (계좌 탭 활성 시에만)
setInterval(()=>{
  if(document.getElementById('page-account').classList.contains('active')) loadAccount();
}, 5000);
})();